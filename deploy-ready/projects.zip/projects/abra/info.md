# Abra

Description: Brand consolidation and responsive website for airline conglomerate
Client: Abra
Agency: Self
Role: Brand design lead
Year: 2025
URL: https://kev.studio/Abra
Page Title: kev.studio - Abra

--- CONTENT ---
Abra's rebrand united several regional airlines under a single banner while nodding to the heritage of Pan Am. As brand design lead, I worked closely with the Jones & Co. team to craft a flexible identity system and responsive site. Interactive prototypes guided our animation and transition work, ensuring the experience feels modern without revealing sensitive executive details.
