# Fiserv

URL: https://kev.studio/Fiserv

Page Title: Fiserv — kev.studio
Agency: In-house
Description: 2017 Programming financial reform Back in 2016, the Department of Labor announced that all fees, decisions, and transactions made by financial advisors would need...

--- CONTENT ---

kevin grzejkais a designer from new jersey


	



 



	
	
︎ LINKS

︎︎︎   ︎︎︎

︎︎︎   ︎︎︎

2017
	
Programming financial reformBack in 2016, the Department of Labor announced that all fees, decisions, and transactions made by financial advisors would need to be disclosed to their clients. Historically, this data had always been opaque — how should we gather and present it?On the Statement Reporting team at Fiserv, we used a combo of code (in APL and PostScript) and design (in Exstream) to create dynamically-generated reports for millions of people. 
To create a new digital product to meet the DOL’s new law, it took five months of producing a slew of new functions, design templates, product sales pitches, QA reports and load testing scenarios before we were finally ready for launch.
But, the Trump administration won election and froze the new law before finally killing it off. 

Company: FiservDivision: Statement ReportingRole: Design, programming, Qa
STRATEGY: MIKE SNIZEK
Lead programmer: Prital Patel
sample APL code below by alex weiner is here


	





	










	









	
	


	
	


	

	
	

	

	
	
	

				

				
 
 
  Mark

2017

Programming financial reform

grzejkakevin@gmail.com


	
	︎   @k gosh
︎   @kevingrz

	
︎   museum
︎   links












	
	©2025 site by kevin grzejka

