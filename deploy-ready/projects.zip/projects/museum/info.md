# Museum

Description: Collection of paintings on canvas and board created with acrylic, watercolor, and oil.
Client: Personal
Agency: Self
Role: Artist
Year: 2018-2024

--- CONTENT ---

A series of personal artworks exploring color and composition across different mediums. All works were photographed or scanned with minimal digital retouching for color correction and drop shadows.
