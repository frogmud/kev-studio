# American Social

## Metadata
Year: 2020
Client: Keeley Gould
Agency: Thackway McCord
Role: Design, Motion, Programming
Categories: Digital
Tags: Animation

--- CONTENT ---
Worked on the credits, title sequence, and promotional website for the short film "American Social."

The film won best cinematography at the NY International Women Festival. Agency: Thackway McCord.

--- TIMELINE ---

### Title & Credits
Designed the typography and motion for the film's opening titles and end credits.

### Website
Developed a simple landing page to showcase the film and cast information.
