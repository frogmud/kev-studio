# cargo-collective-exodus

Download all the images from a Cargo Collective portfolio

Built for http://cargocollective.com/zeke
