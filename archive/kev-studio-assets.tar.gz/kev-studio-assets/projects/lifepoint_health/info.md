# Lifepoint-Health

URL: https://kev.studio/Lifepoint-Health

Page Title: Lifepoint Health — kev.studio
Description: 2023 Great care lives here Lifepoint is a national for-profit healthcare provider, currently operating in 89 locations across...

--- CONTENT ---

kevin grzejkais a designer from new jersey


	



 



	
	
︎ LINKS

︎︎︎   ︎︎︎

︎︎︎   ︎︎︎

2023
	
Great care lives here































Lifepoint is a national for-profit healthcare provider,
currently operating in 89 locations across the United States. The network is
deeply connected within and committed to the communities it serves. In many of
them, the hospital is as vital a part of community infrastructure as roads and
schools. 



























The heart created the foundation for a visual identity
system based on a palette of clean white and vibrant color, applied through a
rigorously developed library of crop configurations originating from the dot motif. 










Agency: Thackway McCord
Client: LIFEPOINT HEALTH
Role: DESIGN LEAD, LOGO, MOTION, ENVIRONMENTS, PRINT
Creative direction: kat mccord
DESIGN: BIANCA SEONG, FUCHEN KUANG
Strategy: Simon Thackway, Jonathan Paisner



	
	

	






















	




				

				
 
 
  Mark

2023

Great care lives here

grzejkakevin@gmail.com


	
	︎   @k gosh
︎   @kevingrz

	
︎   museum
︎   links












	
	©2025 site by kevin grzejka

