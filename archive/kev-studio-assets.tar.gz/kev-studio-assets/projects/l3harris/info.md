# L3Harris

URL: https://kev.studio/L3Harris

Page Title: L3Harris — kev.studio
Description: 2018 L3Harris, a merger of equals When L3 Technologies and Harris announced that they were merging in late 2018, it was billed as the largest defense merger...

--- CONTENT ---

kevin grzejkais a designer from new jersey


	



 



	
	
︎ LINKS

︎︎︎   ︎︎︎

︎︎︎   ︎︎︎

2018
	
L3Harris, a merger of equalsWhen L3 Technologies and Harris announced that they were merging in late 2018, it was billed as the largest defense merger in history, creating the sixth largest defense company in the world. This new company needed to communicate scale, resources, and capabilities, while separating itself from the top brands that dominated the space.The
new brand needed to unite the shared vision of two CEOs and provide
a foundation where two systems, two 
cultures, and two groups of employees could be brought together. In addition, all of the work - from
discovery, strategy and logo development, to visual identity and guidelines -
was created in a climate of total confidentiality, in
close collaboration with our client counterparts. 

Agency: Thackway McCordClient: L3HarrisRole: Design, LOGO, motion, ui/uxCreative direction: Kat McCord
DESIGN LEAD: david weiss
Strategy: Simon Thackway, Jonathan Paisner
Logo animation: Scyld Bowring
Original geodesic dome script by aadebdeb



	





	





	








	








	








				

				
 
 
  Mark

2018

L3Harris, a merger of equals

grzejkakevin@gmail.com


	
	︎   @k gosh
︎   @kevingrz

	
︎   museum
︎   links












	
	©2025 site by kevin grzejka

