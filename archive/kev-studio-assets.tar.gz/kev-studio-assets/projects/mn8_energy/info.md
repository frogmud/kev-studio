# MN8 Energy

URL: https://kev.studio/MN8-Energy

Page Title: MN8 Energy — kev.studio
Description: 2024 You got power MN8 is the enterprise renewable energy company, relentlessly making energy smarter, cleaner, more accessible...

--- CONTENT ---

kevin grzejkais a designer from new jersey


	



 



	
	
︎ LINKS

︎︎︎   ︎︎︎

︎︎︎   ︎︎︎

2024
	
You got power































MN8 is the enterprise renewable energy company, relentlessly making energy smarter, cleaner, more accessible and more efficient. Goldman Sachs’s spin-out of its renewable energy business created a paradigm-shifting opportunity to put power – literally and metaphorically – in the hands of the customer.
The logo concept and “all orange everything” ideas were all Steve and Kat; the negative space 8/colon/power socket logo concept was a winner early on. I worked on naming, logo concepting, website design, design systems, and the guidelines.










Agency: Thackway McCord
Client: GOLDMAN SACHS & mn8 energy 
Role: DESIGN, LOGO, MOTION, QA, ui/ux
executive Creative direction: kat mccord
design lead & creative direction: steve clarke
client services: lucinda quartararo
PROGRAMMING: dave morreale
Strategy: Simon Thackway, Jonathan Paisner



	
	

	















	




				

				
 
 
  Mark

2024

You got power

grzejkakevin@gmail.com


	
	︎   @k gosh
︎   @kevingrz

	
︎   museum
︎   links












	
	©2025 site by kevin grzejka

