# Sylvamo

URL: https://kev.studio/Sylvamo

Page Title: Sylvamo — kev.studio
Description: 2021 Sylvamo, the ‘World’s Paper Company’ Sylvamo is the world's paper company, honoring the promise of paper to educate, communicate and...

--- CONTENT ---

kevin grzejkais a designer from new jersey


	



 



	
	
︎ LINKS

︎︎︎   ︎︎︎

︎︎︎   ︎︎︎

2021
	
Sylvamo, the ‘World’s Paper Company’











Sylvamo is the world's paper company, honoring the promise of paper to educate, communicate and entertain – sustainably. Thackway McCord created the name Sylvamo when the company spun off from International Paper creating the worlds largest pure play paper production business. 
Sylvamo, reflecting the company's role as a steward of sustainable forests, combines the Latin words for forest, “silva,” and love, “amo” creating “love of forests.” The paper plane icon is a symbol of aspiration and business focus, the warm purple color connotes both love and stability and is unique in a marketplace of green and the paper wave supergraphic suggest opportunity and progress.



Agency: Thackway McCord
ClientS: Sylvamo, INTERNATIONAL PAPER
Role: design lead, logo, MOTION, print
exec Creative director: kat mccord
Creative director: steve clarke
Strategy: Simon Thackway, Jonathan Paisner
3d work: Scyld Bowring

🏆🏆🏆 AWARDS: 
INDIGO DESIGN AWARDS 2022 (GOLD – BRANDING)12TH WOLDA DESIGN AWARDS (GOLD – THE AMERICAS)logolounge (book 13)

	





	

	




	








	



	








	



				

				
 
 
  Mark

2021

Sylvamo, the ‘World’s Paper Company’

grzejkakevin@gmail.com


	
	︎   @k gosh
︎   @kevingrz

	
︎   museum
︎   links












	
	©2025 site by kevin grzejka

