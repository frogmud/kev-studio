# American Social

URL: https://kev.studio/American-Social

Page Title: American Social — kev.studio
Description: 2020 American Social Worked on the credits, title sequence, and website for the short film, ‘American Social.’ Winner of best cinematography...

--- CONTENT ---

kevin grzejkais a designer from new jersey


	



 



	
	
︎ LINKS

︎︎︎   ︎︎︎

︎︎︎   ︎︎︎

2020
	
American Social










Worked on the credits, title sequence, and website for the short film, ‘American Social.’ 
Winner of best cinematography at the NY International Women Festival — go Keeley!
Agency: Thackway McCord
Client: KEELEY GOULD
Role: DESIGN, MOTION, PROGRAMMING
LINK: IMDB 
Creative direction: KAT MCCORD


	





	

	




	



	
	

	

				

				
 
 
  Mark

2020

American Social

grzejkakevin@gmail.com


	
	︎   @k gosh
︎   @kevingrz

	
︎   museum
︎   links












	
	©2025 site by kevin grzejka

