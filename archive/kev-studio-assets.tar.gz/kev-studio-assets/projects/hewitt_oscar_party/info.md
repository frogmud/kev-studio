# Hewitt-Oscar-Party

URL: https://kev.studio/Hewitt-Oscar-Party

Page Title: Hewitt Oscar Party — kev.studio
Description: 2000 to 2020 The Hewitt Oscar Party Since 1999, the Hewitt family and friends celebrate Kevin Hewitt's birthday by dressing up as characters from...

--- CONTENT ---

kevin grzejkais a designer from new jersey


	



 



	
	
︎ LINKS

2000 to 2020
	
The Hewitt Oscar PartySince 1999, the Hewitt family and friends celebrate Kevin Hewitt's birthday by dressing up as characters from Academy-Award-nominated movies and throwing a wacky costume party. Over the years, an enormous amount of material has been collected by dozens of people as polaroids, casettes and usb drives.
In 2015, I gathered and scanned around 2,500 photos while digitizing a bin full of USBs and casettes. I love my family. 😊



	





	









	



	
	

				

				
 
 
  Mark

2000 to 2020

The Hewitt Oscar Party

grzejkakevin@gmail.com


	
	︎   @k gosh
︎   @kevingrz

	
︎   museum
︎   links












	
	©2025 site by kevin grzejka

