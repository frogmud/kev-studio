# Eyes Above

URL: https://kev.studio/Eyes-Above

Page Title: Eyes Above — kev.studio
Description: 2022 Eyes Above A short story written by my brother based on five years of DnD campaigns leads to a deep dive into character...

--- CONTENT ---

kevin grzejkais a designer from new jersey


	



 



	
	
︎ LINKS

︎︎︎   ︎︎︎

︎︎︎   ︎︎︎

2022
	
Eyes Above































A short story written by my brother based on five years of DnD campaigns leads to a deep dive into character animation.
Scalability as priority drives the style of bright, saturated colors and thick outlines. Ultimately, the goal is to build a video game demo with a full color animation intro, but...
As everyone warned me, hand drawn animation takes forever. Drawing non-stop for around 9 months, the only character animations were black and white sprites. Still wanting to send this in my Young Guns 21 entry, I tried to make it feel as finished as possible (was not shortlisted ☹️). 
Its been hard to pick this project back up since. My hands were always ache-y from drawing at night after designing during the day...












Role: DIRECTION, ILLUSTRATion, DESIGN, MOTION, GAME DESIGN
READ STORY HERE: https://eyesabove.info
SPECIAL THANKS TO: BRIAN APPLEBY, KEITH HAGINS, CHRIS STRATTON, RYAN HAWK, & james grzejka



	
	


	
	



















				

				
 
 
  Mark

2022

Eyes Above

grzejkakevin@gmail.com


	
	︎   @k gosh
︎   @kevingrz

	
︎   museum
︎   links












	
	©2025 site by kevin grzejka

