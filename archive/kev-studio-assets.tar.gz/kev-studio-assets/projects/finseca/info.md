# Finseca

URL: https://kev.studio/Finseca

Page Title: Finseca — kev.studio
Description: 2020 Financial security for all The merger of AALU and GAMA in September 2020 was a merger formed with the goal of uniting the life insurance industry. The...

--- CONTENT ---

kevin grzejkais a designer from new jersey


	



 



	
	
︎ LINKS

︎︎︎   ︎︎︎

︎︎︎   ︎︎︎

2020
	
Financial security for allThe merger of AALU and GAMA in September 2020 was a merger formed with the goal of uniting the life insurance industry. The broader and more profound commitment they unified under was to elevate the profession.At the core of the brief is financial security, leading to the acro-name and shield motif. The two F’s in the logo represent the two equals coming together, while the purple color scheme stakes the DC-based organization as politically ‘neutral’, both red and blue.
Agency: Thackway McCord
Client: Finseca
Role: DESIGN LEAD, motion, ui/ux
Creative direction: Kat McCorddesign: fuchen kuang
Strategy: Simon Thackway, Jonathan Paisner
Website: WDG
3d work: Scyld Bowring
🏆🏆🏆 AWARDS: indigo design awards 2021 branding (silver)Wolda 2020 logo (gold)best brand awards 2021 (silver)


	





	


	



	






	



	







	



				

				
 
 
  Mark

2020

Financial security for all

grzejkakevin@gmail.com


	
	︎   @k gosh
︎   @kevingrz

	
︎   museum
︎   links












	
	©2025 site by kevin grzejka

