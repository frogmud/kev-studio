# Main-Page

URL: https://kev.studio/Main-Page

Page Title: kev.studio
Description: Kevin Grzejka is a designer from New Jersey

--- CONTENT ---

kevin grzejkais a designer from new jersey


	



 



	
	
︎ LINKS

Absorb Software
Website & rebrand for learning tech company



	MN8 EnergyWebsite & guidelines for GS spin-off




	AbraWebsite & rebrand


	

	Lifepoint HealthBranding a national healthcare network




	OnityStoryboarding, direction for logo animation





	Thackway McCord petsMaking QR codes fun!



	Eyes AboveWerewolves & wraiths oh my




	HumBranding a new way to fund growth





	AIGA Holiday fundraiser





	
Sylvamo Branding for International Paper spinoff








	

	
American Social
Title & end credits




	Finseca 
Branding for merger









	LREI 
Viewbook



	
Amrop
Brand refresh & website
 





	Tryitout with Major League WiffleballBranding & game 1 starter





	

L3HarrisBranding for merger

Absorb Software
Website & rebrand for learning tech company

MN8 EnergyWebsite & guidelines for GS spin-off

AbraWebsite & rebrand

Lifepoint HealthBranding a national healthcare network

OnityStoryboarding, direction for logo animation

Thackway McCord petsMaking QR codes fun!

Eyes AboveWerewolves & wraiths oh my

HumBranding a new way to fund growth

AIGA Holiday fundraiser

Sylvamo Branding for International Paper spinoff

American Social
Title & end credits

Finseca 
Branding for merger

LREI

Viewbook

Amrop
Brand refresh & website

Tryitout with Major League Wiffleball

Branding & game 1 starter

L3HarrisBranding for merger

grzejkakevin@gmail.com


	
	︎   @k gosh
︎   @kevingrz

	
︎   museum
︎   links












	
	©2025 site by kevin grzejka

