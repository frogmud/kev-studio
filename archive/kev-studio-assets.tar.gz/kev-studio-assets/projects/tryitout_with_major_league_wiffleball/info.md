# Tryitout with Major League Wiffleball

URL: https://kev.studio/TryItOut-with-Major-League-Wiffleball

Page Title: TryItOut with Major League Wiffleball — kev.studio
Description: 2018 Tryitout with Major League Wiffleball Five adult men play in a wiffleball tournament on Long Island; will branding help give them the edge they need? The...

--- CONTENT ---

kevin grzejkais a designer from new jersey


	



 



	
	
︎ LINKS

︎︎︎   ︎︎︎

︎︎︎   ︎︎︎

2018
	
Tryitout with Major League WiffleballFive adult men play in a wiffleball tournament on Long Island; will branding help give them the edge they need?
The logo itself is a traditional-feeling cursive sports logo, aligned by the identical ‘t’ used at the beginning, middle, and end. Bright green as the team colors works to reflect the feeling of playing ball in the yard.
Despite our branding efforts, we lost in the semi-finals to 16-year olds. 
Agency: SelfRole: Art direction, print, motion, ace pitcher
Link: Some game footage




	





	
	
 


    	







	




	




	
	













	
	


	


	  ↓  WATCH GAME FOOTAGE  ↓  WATCH GAME FOOTAGE  ↓  WATCH GAME FOOTAGE  ↓  WATCH GAME FOOTAGE  ↓ WATCH GAME FOOTAGE  ↓  






	
	
	



				

				
 
 
  Mark

2018

Tryitout with Major League Wiffleball

grzejkakevin@gmail.com


	
	︎   @k gosh
︎   @kevingrz

	
︎   museum
︎   links












	
	©2025 site by kevin grzejka

