# AIGA

URL: https://kev.studio/joy-joy-joy-joy-joy

Page Title: joy joy joy joy joy — kev.studio
Description: 2021 Joy with the AIGA  For the 2021 holidays, the AIGA wanted to sell some wrapping paper around the theme of ‘joy.’ We got joyjoyjoyjoyjoy.com and built...

--- CONTENT ---

kevin grzejkais a designer from new jersey


	



 



	
	
︎ LINKS

︎︎︎   ︎︎︎

︎︎︎   ︎︎︎

2021
	
Joy with the AIGA For the 2021 holidays, the AIGA wanted to sell some wrapping paper around the theme of ‘joy.’We got joyjoyjoyjoyjoy.com and built some festive QR codes to link to a fun, lightweight animation based on the look and feel of the code and colors. Because the code artwork was perfect for building a lottie file, we could get the animation to autoplay on mobile after scanning the code instead of some clunkier gif or embed. 😬
A few variations of the festive code are step-repeated to create the wrapping paper. All of them are scannable and lead back to the animation. 
client: aiga nyAgency: Thackway McCordcreative direction: kat mccord
Role: DESIGN, PROGRAMMING, MOTION, printQR LINK: JOYJOYJOYJOYJOY.COM
buy wrapping paper: society6.com


	





	



	




	







	
	
	



				

				
 
 
  Mark

2021

Joy with the AIGA

grzejkakevin@gmail.com


	
	︎   @k gosh
︎   @kevingrz

	
︎   museum
︎   links












	
	©2025 site by kevin grzejka

