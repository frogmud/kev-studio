# LREI

URL: https://kev.studio/LREI-Viewbook

Page Title: LREI Viewbook — kev.studio
Description: 2018 LREI & the 15-year experience Little Red School House and Elisabeth Irwin High School (LREI) is regarded as Manhattan's first progressive school. It's PreK...

--- CONTENT ---

kevin grzejkais a designer from new jersey


	



 



	
	
︎ LINKS

︎︎︎   ︎︎︎

︎︎︎   ︎︎︎

2018
	
LREI & the 15-year experienceLittle Red School House and Elisabeth Irwin High School (LREI) is regarded as Manhattan's first progressive school. It's PreK – 12th grade curriculum is described by the school as a “15-year experience.”


We were given access to a Flickr account with around 5,000 photos and some suggestions for text. As long as the final result would help parent’s understand life at LREI and then fit in their pocket, most ideas were fair game.
The final result was a batch of ten thousand viewbooks that LREI is still handing out today. 😎


Agency: Thackway McCordClient: LREIRole: DESIGN LEAD, PRINT, motion
Creative direction: Kat McCordpress: prestone




	





	



    	

	













				

				
 
 
  Mark

2018

LREI & the 15-year experience

grzejkakevin@gmail.com


	
	︎   @k gosh
︎   @kevingrz

	
︎   museum
︎   links












	
	©2025 site by kevin grzejka

