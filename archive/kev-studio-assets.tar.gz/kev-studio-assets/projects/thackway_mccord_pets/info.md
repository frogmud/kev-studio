# Thackway McCord pets

URL: https://kev.studio/thackwaymccord

Page Title: thackwaymccord — kev.studio
Description: 2022 Making QR codes fun! Every holiday season, Thackway McCord partners with an artist to create a series of chocolate bars to send as gifts. For...

--- CONTENT ---

kevin grzejkais a designer from new jersey


	



 



	
	
︎ LINKS

︎︎︎   ︎︎︎

︎︎︎   ︎︎︎

2022
	
Making QR codes fun!











Every holiday season, Thackway McCord partners with an artist to create a series of chocolate bars to send as gifts. For 2021, I pitched the idea of drawing custom QR codes linking to some fun, TM-branded url. The pandemic had made the codes ubiqutous, but their most common use cases for a no-contact-on-demand-service felt like a missed opportunity. What began as abstract drawings of QR codes (see 01, 02, 03 for examples) ended up as portraits of animals coupled with 8-bit style gifs and stickers with individual phrases and personalities that we were workshopping. Monotype liked how we used Cotford against the glitchy, erratic look of the codes and sprite art. And then our silly gifs started getting popular on giphy  by getting posted as stickers on instagram. 
And finally, and most importantly, my cat starred in the case study alongside his illustration.

Agency: Thackway McCord

Role: ART DIRECTION, DESIGN lead, illustration, MOTION, PROGRAMMING, packaging, PROMO
LINK: thackwaymccord.fun 
models: bean & rosie
creative direction: KAT MCCORD

🏆🏆🏆 AWARDS: 
COMMARTS ILLUSTRATION 2022 (SHORTLISTED)HIIIBRAND ILLUSTRATION 2022 (FINALIST)indigo awards 2022 digital (gold)


	





	



	


	

	


	










	










	
	
	


	
	
	





				

				
 
 
  Mark

2022

Making QR codes fun!

grzejkakevin@gmail.com


	
	︎   @k gosh
︎   @kevingrz

	
︎   museum
︎   links












	
	©2025 site by kevin grzejka

