# Hum

URL: https://kev.studio/Hum

Page Title: Hum — kev.studio
Description: 2021 A better way to fund growth Silicon Valley mixes with Wall Street in Hum’s ‘capital as a service’ business model, designed to help SMBs...

--- CONTENT ---

kevin grzejkais a designer from new jersey


	



 



	
	
︎ LINKS

︎︎︎   ︎︎︎

︎︎︎   ︎︎︎

2021
	
A better way to fund growth











Silicon Valley mixes with Wall Street in Hum’s ‘capital as a service’ business model, designed to help SMBs raise money faster and more easily. A full rebrand provided ‘Capital’, as they were known, with a new name, logo, visual identity and website that capture their iconoclastic, AI-driven, ground-levelling proposition. 
Set up a handover package including the logo artwork, guidelines, and first sprint’s worth of Figma designs and components. 
Bianca Seong (formerly @pixeltometer.com) worked on everything from the logo to the illustrations to the web design and knocked it out of the park.



Agency: Thackway McCord
ClientS: hum capital
Role: LOGO, design, UI/UX
Creative director: kat mccord
LEAD DESIGNER: BIANCA SEONG
Strategy: Simon Thackway, Jonathan Paisnerprogramming: dave morreale
3d work: Scyld Bowring

🏆🏆🏆 AWARDS: transform north america 2021 rebrand (gold)indigo awards 2021 branding (silver)wolda 2021 rebrand (gold)

	





	



	












	



				

				
 
 
  Mark

2021

A better way to fund growth

grzejkakevin@gmail.com


	
	︎   @k gosh
︎   @kevingrz

	
︎   museum
︎   links












	
	©2025 site by kevin grzejka

